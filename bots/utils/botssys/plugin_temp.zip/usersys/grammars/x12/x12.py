from bots.botsconfig import *
from envelope import recorddefs,structure,nextmessage


syntax = { 
        'version'    :  '00403',    #only for sending
        }

