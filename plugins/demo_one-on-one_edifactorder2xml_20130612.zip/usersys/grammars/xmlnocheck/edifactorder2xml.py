from bots.utils.botsconfig import *

syntax = { 
        'merge': False,
        }
