from bots.utils.botsconfig import *
from envelope import recorddefs,structure

nextmessage = ({'BOTSID':'ISA'},)

syntax = { 
        'version'    :  '00403',    #only for sending
        }

