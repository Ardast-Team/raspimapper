#mapping-script
import bots.utils.engine.transform as transform

def main(inn,out):
    transform.inn2out(inn,out)
